import React from 'react'

const Errorpage = () => {
  return (
   <>
   <h1>404 error found</h1>
   <h2>page you are looking not found</h2>
   
   </>
  )
}

export default Errorpage